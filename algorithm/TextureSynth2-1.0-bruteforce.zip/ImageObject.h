#pragma once

#include <vector>
#include <cassert>

#include "Utils.h"
#include "ImageUtils.h"

class Image {

private:

	Dimension dimension;
	std::vector<Pixel> pixelData;

public:

	Image(int width = 0, int height = 0):
		dimension(width, height)
	{
		pixelData.reserve(width*height);
	}

	void SetDimension(const Dimension& d){
		dimension.width = d.width;
		dimension.height = d.height;
	}
	
	Pixel& At(unsigned int x, unsigned int y){
		AssertRT(x * y < unsigned int(dimension.size()));
		AssertRT(x * y < unsigned int(pixelData.size()));
		return pixelData[y * dimension.width + x];
	}

	Pixel& At(const Coordinate& coord){
		return At(coord.x, coord.y);
	}

	std::vector<Pixel>& Data(){
		return pixelData;
	}

};