
//#define DEBUG

#include "TextureGenerator.h"

int main(int argc, char* argv[]){
	TextureGenerator textureGenerator{
		"1.jpg",
		Dimension{256, 512},
		10
	};
	textureGenerator.Generate();
	textureGenerator.SaveToFile("1_out.jpg");

	return 0;
}