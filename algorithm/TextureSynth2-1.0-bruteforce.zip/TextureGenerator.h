#pragma once

#include <cassert>
#include <string>
#include <algorithm>

#include "jpeg-compressor/jpgd.h"
#include "jpeg-compressor/jpge.h"

#include "Utils.h"
#include "ImageObject.h"
#include "ImageUtils.h"
#include "Random.h"

class TextureGenerator{

private:
	static constexpr int COLOR_COMPONENTS = 3;

private:
	Dimension			inputDimension;
	Image				inputImage;
	std::string			inputImagePath;
	std::vector<float>	inputSimilarityGroups;

	Dimension			outputDimension;
	Image				outputImage;

	int					neighbourSize;

public:
	TextureGenerator(
		std::string inputImagePath,
		Dimension outputDimension,
		int neighbourSize
	):
		inputImagePath(inputImagePath),
		outputDimension(outputDimension),
		outputImage(outputDimension.width, outputDimension.height),
		neighbourSize(neighbourSize)
	{
		LoadInputImage();
	}

	void LoadInputImage(){
		int actualPixelSize;
		unsigned char *imageData = jpgd::decompress_jpeg_image_from_file(
			inputImagePath.c_str(),
			&inputDimension.width,
			&inputDimension.height,
			&actualPixelSize,
			COLOR_COMPONENTS
		);
		AssertRT(actualPixelSize == COLOR_COMPONENTS);

		inputImage.SetDimension(inputDimension);
		int inputImageRawSize = inputDimension.size() * 3;
		for (int i = 0; i < inputImageRawSize; i += 3){
			float r = float(imageData[i + 0]) / 255.f;
			float g = float(imageData[i + 1]) / 255.f;
			float b = float(imageData[i + 2]) / 255.f;
			inputImage.Data().emplace_back(r, g, b);
		}
		free(imageData);
	}

	float GetColorDistanceSquared(const ColorData& a, const ColorData& b){
		return
			(a.r - b.r)*(a.r - b.r) +
			(a.g - b.g)*(a.g - b.g) +
			(a.b - b.b)*(a.b - b.b);
	}

	inline Coordinate TileizeCoordinate(Coordinate coord, Dimension dimension){
		Coordinate tileizedCoord{coord};

		// y
		if (coord.y < 0){
			tileizedCoord.y = (coord.y + dimension.height) % dimension.height;
		} else{
			tileizedCoord.y = coord.y % dimension.height;
		}

		// x
		if (coord.x < 0){
			tileizedCoord.x = (coord.x + dimension.width) % dimension.width;
		} else{
			tileizedCoord.x = coord.x % dimension.width;
		}

		return tileizedCoord;
	};

	void FillOutputWithNoise(){
		RandomGenerator randomGenerator{0, double(inputDimension.size())};
		for (int hOut = 0; hOut < outputDimension.height; hOut++){
			for (int wOut = 0; wOut < outputDimension.width; wOut++){
				const int randomInputPosition = int(randomGenerator());
				const Pixel& pixel = inputImage.Data()[randomInputPosition];
				outputImage.Data().emplace_back(pixel);
			}
		}
		AssertRT(outputImage.Data().size() == outputDimension.size());
	}

	void Generate(){

		// fill up the output image with noise from input image
		FillOutputWithNoise();

		// walk over every pixel on the output image
		for (int hOut = 0; hOut < outputDimension.height; hOut++){
			for (int wOut = 0; wOut < outputDimension.width; wOut++){

				// for this given output coord, get the surrounding neighbours
				// it should be an odd number because the middle is the current output pixel
				constexpr int neighbourSize = 3;
				AssertCT(neighbourSize % 2 == 1);
				std::vector<const Pixel *> outNeighbours;
				for (int hOffset = hOut - neighbourSize; hOffset <= hOut; ++hOffset){
					for (int wOffset = wOut - neighbourSize; wOffset <= wOut + neighbourSize; ++wOffset){
						if (hOffset == hOut && wOffset == wOut){
							// ends loops
							hOffset = INT_MAX-1;
							wOffset = INT_MAX-1;
							break;
						}
						Coordinate offsetCoord{wOffset, hOffset};
						Coordinate tileizedCoord = TileizeCoordinate(offsetCoord, outputDimension);
						const Pixel* outNeighbourPtr = &(outputImage.At(tileizedCoord));
						outNeighbours.push_back(outNeighbourPtr);
					}
				}
				AssertRT(outNeighbours.size() == (neighbourSize+1)*(2*neighbourSize+1) - (neighbourSize+1));

				Coordinate candidateInputPixel;
				float neighbourhoodMinimalDistance = FLT_MAX;
				for (int hIn = 0; hIn < inputDimension.height; ++hIn){
					for (int wIn = 0; wIn < inputDimension.height; ++wIn){
						// collect neighbour area of input image to a temporary container
						float inputNeighbourhoodDistance = 0;
						float foundPixelCount = 0;
						for (int hInBlock = -neighbourSize; hInBlock <= neighbourSize; ++hInBlock){
							for (int wInBlock = -neighbourSize; wInBlock <= neighbourSize; ++wInBlock){
								if ((hInBlock | wInBlock) == 0){
									// ends loops
									hInBlock = INT_MAX-1;
									wInBlock = INT_MAX-1;
									break;
								} else {
									if (hIn + hInBlock >= 0 &&
										hIn + hInBlock < inputDimension.height &&
										wIn + wInBlock >= 0 &&
										wIn + wInBlock < inputDimension.width
									){
										int hInContainer = hInBlock + neighbourSize;
										int wInContainer = wInBlock + neighbourSize;
										const Pixel&  inputPixel = inputImage.At(wIn + wInBlock, hIn + hInBlock);
										const Pixel& outputPixel = *outNeighbours.at(hInContainer * (2*neighbourSize+1) + wInContainer);
										inputNeighbourhoodDistance += GetColorDistanceSquared(inputPixel, outputPixel);
										foundPixelCount += 1.0f;
									}
								}
							}
						}
						if (foundPixelCount > float(neighbourSize*neighbourSize*2)){
							inputNeighbourhoodDistance = inputNeighbourhoodDistance / foundPixelCount;
							float threshold = 0.002f;
							if (inputNeighbourhoodDistance <= threshold){
								inputNeighbourhoodDistance = FLT_MAX;
							}
							if (inputNeighbourhoodDistance < neighbourhoodMinimalDistance){
								neighbourhoodMinimalDistance = inputNeighbourhoodDistance;
								candidateInputPixel.y = hIn;
								candidateInputPixel.x = wIn;
							}
						}
					}
				}

				outputImage.At(wOut, hOut) = inputImage.At(candidateInputPixel);
			}
		}
	}

	void SaveToFile(std::string outputImagePath){
		std::vector<unsigned char> outputImageBuffer;
		std::for_each(
			outputImage.Data().cbegin(),
			outputImage.Data().cend(),
			[&outputImageBuffer](const Pixel& pixel){
			outputImageBuffer.push_back(unsigned char(pixel.r*255.f));
			outputImageBuffer.push_back(unsigned char(pixel.g*255.f));
			outputImageBuffer.push_back(unsigned char(pixel.b*255.f));
		}
		);
		bool resultOfCompression = jpge::compress_image_to_jpeg_file(
			outputImagePath.c_str(),
			outputDimension.width,
			outputDimension.height,
			COLOR_COMPONENTS,
			outputImageBuffer.data()
		);
	}

};