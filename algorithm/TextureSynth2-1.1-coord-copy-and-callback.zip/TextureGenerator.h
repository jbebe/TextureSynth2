#pragma once

#include <cassert>
#include <string>
#include <algorithm>
#include <functional>

#include "jpeg-compressor/jpgd.h"
#include "jpeg-compressor/jpge.h"

#include "Utils.h"
#include "ImageObject.h"
#include "ImageUtils.h"
#include "Random.h"

class TextureGenerator {

private:
	static constexpr int COLOR_COMPONENTS = 3;

private:
	Dimension		inputDimension;
	PixelImage		inputImage;
	std::string		inputImagePath;

	Dimension		outputDimension;
	ReferenceImage	outputRefImage;
	PixelImage		outputImage;

	int				neighbourSize;
	float			similarityThreshold;

public:
	TextureGenerator(
		std::string inputImagePath,
		Dimension outputDimension,
		int neighbourSize,
		float similarityThreshold
	):
		inputImagePath(inputImagePath),
		outputDimension(outputDimension),
		outputRefImage(outputDimension.width, outputDimension.height),
		outputImage(outputDimension.width, outputDimension.height),
		neighbourSize(neighbourSize),
		similarityThreshold(similarityThreshold)
	{
		LoadInputImage();
	}

	void LoadInputImage(){
		int actualPixelSize;
		unsigned char *imageData = jpgd::decompress_jpeg_image_from_file(
			inputImagePath.c_str(),
			&inputDimension.width,
			&inputDimension.height,
			&actualPixelSize,
			COLOR_COMPONENTS
		);
		AssertRT(actualPixelSize == COLOR_COMPONENTS);

		inputImage.SetDimension(inputDimension);
		int inputImageRawSize = inputDimension.size() * 3;
		for (int i = 0; i < inputImageRawSize; i += 3){
			float r = float(imageData[i + 0]) / 255.f;
			float g = float(imageData[i + 1]) / 255.f;
			float b = float(imageData[i + 2]) / 255.f;
			inputImage.Data().emplace_back(r, g, b);
		}
		free(imageData);
	}

	float GetColorDistanceSquared(const ColorData& a, const ColorData& b){
		return
			(a.r - b.r)*(a.r - b.r) +
			(a.g - b.g)*(a.g - b.g) +
			(a.b - b.b)*(a.b - b.b);
	}

	inline int TileizeValue(int value, int max){
		if (value < 0){
			return (value + max) % max;
		} else{
			return value % max;
		}
	}

	inline Coordinate TileizeCoordinate(const Coordinate& coord, const Dimension& dimension){
		Coordinate tileizedCoord{coord};

		tileizedCoord.y = TileizeValue(coord.y, dimension.height);
		tileizedCoord.x = TileizeValue(coord.x, dimension.width);
		
		return tileizedCoord;
	};

	void FillReferenceOutputWithNoise(){
		RandomGenerator randomGenerator{0, double(inputDimension.size())};
		for (int hOut = 0; hOut < outputDimension.height; hOut++){
			for (int wOut = 0; wOut < outputDimension.width; wOut++){
				const int randomInputPosition = int(randomGenerator());
				outputRefImage.Data().push_back(randomInputPosition);
			}
		}
		AssertRT(outputRefImage.Data().size() == outputDimension.size());
	}

	void Generate(const std::function<void(float)>& callback){

		// fill up the output image with noise from input image
		FillReferenceOutputWithNoise();

		// walk over every pixel on the output image
		for (int hOut = 0; hOut < outputDimension.height; hOut++){
			for (int wOut = 0; wOut < outputDimension.width; wOut++){

				// for this given output coord, get the surrounding neighbours
				// it should be an odd number because the middle is the current output pixel
				constexpr int neighbourSize = 3;
				AssertCT(neighbourSize % 2 == 1);
				std::vector<int> outNeighbours;
				for (int hOffset = hOut - neighbourSize; hOffset <= hOut; ++hOffset){
					for (int wOffset = wOut - neighbourSize; wOffset <= wOut + neighbourSize; ++wOffset){
						if (hOffset == hOut && wOffset == wOut){
							// ends loops
							hOffset = INT_MAX-1;
							wOffset = INT_MAX-1;
							break;
						}
						Coordinate offsetCoord{wOffset, hOffset};
						Coordinate tileizedCoord = TileizeCoordinate(offsetCoord, outputDimension);
						const int outNeighbourOffset = outputRefImage.At(tileizedCoord);
						outNeighbours.push_back(outNeighbourOffset);
					}
				}
				AssertRT(outNeighbours.size() == (neighbourSize+1)*(2*neighbourSize+1) - (neighbourSize+1));

				Coordinate candidateInputPixel;
				float neighbourhoodMinimalDistance = FLT_MAX;
				for (int hIn = 0; hIn < inputDimension.height; ++hIn){
					for (int wIn = 0; wIn < inputDimension.height; ++wIn){
						// collect neighbour area of input image to a temporary container
						float inputNeighbourhoodDistance = 0;
						float foundPixelCount = 0;
						for (int hInBlock = -neighbourSize; hInBlock <= neighbourSize; ++hInBlock){
							for (int wInBlock = -neighbourSize; wInBlock <= neighbourSize; ++wInBlock){
								if ((hInBlock | wInBlock) == 0){
									// ends loops
									hInBlock = INT_MAX-1;
									wInBlock = INT_MAX-1;
									break;
								} else {
									if (hIn + hInBlock >= 0 &&
										hIn + hInBlock < inputDimension.height &&
										wIn + wInBlock >= 0 &&
										wIn + wInBlock < inputDimension.width
									){
										int hInContainer = hInBlock + neighbourSize;
										int wInContainer = wInBlock + neighbourSize;
										const Pixel&  inputPixel = inputImage.At(wIn + wInBlock, hIn + hInBlock);
										const int neighbourOffset = outNeighbours.at(hInContainer * (2 * neighbourSize + 1) + wInContainer);
										const Pixel& outputPixel = inputImage.At(neighbourOffset);
										inputNeighbourhoodDistance += GetColorDistanceSquared(inputPixel, outputPixel);
										foundPixelCount += 1.0f;
									}
								}
							}
						}
						if (foundPixelCount > float(neighbourSize*neighbourSize*2)){
							inputNeighbourhoodDistance = inputNeighbourhoodDistance / foundPixelCount;
							if (inputNeighbourhoodDistance <= similarityThreshold){
								inputNeighbourhoodDistance = FLT_MAX;
							}
							if (inputNeighbourhoodDistance < neighbourhoodMinimalDistance){
								neighbourhoodMinimalDistance = inputNeighbourhoodDistance;
								candidateInputPixel.y = hIn;
								candidateInputPixel.x = wIn;
							}
						}
					}
				}
				outputRefImage.At(wOut, hOut) = candidateInputPixel.y * inputDimension.width + candidateInputPixel.x;
			}
			callback(float(hOut)/float(outputDimension.height));
		}
	}

	void SaveToFile(std::string outputImagePath){
		std::vector<unsigned char> outputImageBuffer;
		std::for_each(
			outputRefImage.Data().cbegin(),
			outputRefImage.Data().cend(),
			[&](const int inputOffset){
				const Pixel& pixel = inputImage.At(inputOffset);
				outputImageBuffer.push_back(unsigned char(pixel.r*255.f));
				outputImageBuffer.push_back(unsigned char(pixel.g*255.f));
				outputImageBuffer.push_back(unsigned char(pixel.b*255.f));
			}
		);
		bool resultOfCompression = jpge::compress_image_to_jpeg_file(
			outputImagePath.c_str(),
			outputDimension.width,
			outputDimension.height,
			COLOR_COMPONENTS,
			outputImageBuffer.data()
		);
	}

};